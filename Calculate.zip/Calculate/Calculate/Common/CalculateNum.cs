﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculate.Common
{
    public class CalculateNum
    {
        /// <summary>
        /// 获取输出的数组
        /// </summary>
        /// <param name="num">循环次数</param>
        /// <returns></returns>
        public static List<string> GetOutputList(int num)
        {
            List<string> strList = new List<string>();//声明返回的集合
            for (int i = 1; i <= num; ++i)
            {
                if (i % 3 == 0 && i % 5 == 0)//先判断既能被3整除，又能被5整除的
                {
                    strList.Add("输出值为FizzBuzz，当前数字为" + i);
                }
                else if (i % 3 == 0)//被3整除
                {
                    strList.Add("输出值为Fizz，当前数字为" + i);
                }
                else if (i % 5 == 0)//被5整除
                {
                    strList.Add("输出值为Buzz，当前数字为" + i);
                }
            }
            return strList;
        }
    }
}
