﻿using Calculate.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculate
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 100;//声明传入参数
            List<string> strList = null;//声明接收对象
            strList = CalculateNum.GetOutputList(num);//获取数据
            if (strList.Count > 0)//判断获取的数量
            {
                //循环打印
                foreach (string str in strList)
                {
                    Console.WriteLine(str);
                }
            }
            Console.ReadLine();
        }
    }
}
